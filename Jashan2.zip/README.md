# Vaultly Backend

API server for Vaultly: encrypted backup, restore on a new phone, last-known-location, and remote wipe.

## Files
- `server.js` - the whole API (auth, device location/wipe, backups). Creates its own database tables on first start.
- `package.json` - dependencies and the start command.

## Environment variables (set these in your host, never commit them)
| Name | What it is |
|---|---|
| `DATABASE_URL` | PostgreSQL connection URL |
| `JWT_SECRET` | Long random string used to sign login tokens |
| `DATA_ENCRYPTION_KEY` | Exactly 64 hex characters (32 bytes) used for AES-256 encryption of backups |
| `NODE_ENV` | `production` |
| `ALLOWED_ORIGINS` | `*` while testing, then your own domains, comma separated |
| `DATABASE_SSL` | Optional. Set to `true` only if your database requires SSL and the URL has no `sslmode` |

Generate secrets with:
```
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

## Deploy on Render
1. New + > Web Service > pick this repo
2. Build Command: `npm install`
3. Start Command: `npm start`
4. Add the environment variables above
5. Open `https://YOUR-SERVICE.onrender.com/health` - you should see `{"status":"ok"}`

## Endpoints
- `POST /auth/signup`, `POST /auth/login`, `POST /auth/verify-device`
- `POST /device/location`, `GET /device/location/:deviceId`
- `POST /device/wipe/:deviceId`, `GET /device/status/:deviceId`
- `POST /backup/upload`, `GET /backup/restore/:category` (contacts, photos, files)

## Limits to know about
- Location is recorded only while the phone is on; nothing can locate a phone that is fully powered off.
- iOS does not allow third-party apps to read SMS or call logs, so those are not backed up.
- Remote wipe only removes Vaultly's own data and only works once the old phone next connects.
