require('dotenv').config();
const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const { Pool } = require('pg');

// ---------- Configuration check (fails fast with a clear message) ----------
const missing = ['DATABASE_URL', 'JWT_SECRET', 'DATA_ENCRYPTION_KEY'].filter((k) => !process.env[k]);
if (missing.length > 0) {
  console.error('Missing environment variables: ' + missing.join(', '));
  process.exit(1);
}
if (!/^[0-9a-fA-F]{64}$/.test(process.env.DATA_ENCRYPTION_KEY)) {
  console.error('DATA_ENCRYPTION_KEY must be exactly 64 hex characters (0-9, a-f).');
  process.exit(1);
}

const JWT_SECRET = process.env.JWT_SECRET;
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';
const KEY = Buffer.from(process.env.DATA_ENCRYPTION_KEY, 'hex');
const BCRYPT_ROUNDS = 12;
const DUMMY_HASH = bcrypt.hashSync('dummy-password-for-timing-defense', BCRYPT_ROUNDS);

// ---------- Database ----------
// Set DATABASE_SSL=true only if your database provider requires SSL and the
// connection URL doesn't already include sslmode.
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : undefined,
});
const db = { query: (text, params) => pool.query(text, params) };

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  vault_id TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  security_question TEXT NOT NULL,
  security_answer_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS devices (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_id TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  first_seen TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_seen TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS device_locations (
  id SERIAL PRIMARY KEY,
  device_id TEXT NOT NULL REFERENCES devices(device_id) ON DELETE CASCADE,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  accuracy_meters REAL,
  battery_percent SMALLINT,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_device_locations_device_time
  ON device_locations (device_id, recorded_at DESC);
CREATE TABLE IF NOT EXISTS backups (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  encrypted_payload TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, category)
);
`;

async function initDb() {
  await db.query(SCHEMA); // creates the tables on first start; safe to run every time
}

// ---------- Encryption (AES-256-GCM) for backup data at rest ----------
function encrypt(plaintext) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', KEY, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), encrypted]).toString('base64');
}

function decrypt(payloadBase64) {
  const payload = Buffer.from(payloadBase64, 'base64');
  const decipher = crypto.createDecipheriv('aes-256-gcm', KEY, payload.subarray(0, 12));
  decipher.setAuthTag(payload.subarray(12, 28));
  return Buffer.concat([decipher.update(payload.subarray(28)), decipher.final()]).toString('utf8');
}

// ---------- App setup ----------
const app = express();
app.set('trust proxy', 1); // Render sits behind a proxy; needed for correct per-user rate limiting
app.use(helmet());

const allowedOrigins = (process.env.ALLOWED_ORIGINS || '*').split(',').map((s) => s.trim()).filter(Boolean);
app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin)) return callback(null, true);
      return callback(new Error('Origin not allowed'));
    },
  })
);

app.use(express.json({ limit: '2mb' }));

app.use(
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 300,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many requests. Please slow down.' },
  })
);

// Stricter limit on login-type endpoints to blunt brute-force attacks
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Please try again later.' },
});

function handleValidation(req, res, next) {
  if (!validationResult(req).isEmpty()) return res.status(400).json({ error: 'Invalid input.' });
  next();
}

function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid authorization header' });
  }
  try {
    const payload = jwt.verify(header.split(' ')[1], JWT_SECRET);
    if (payload.stage) return res.status(401).json({ error: 'Session invalid or expired. Please log in again.' });
    req.userId = payload.sub;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Session invalid or expired. Please log in again.' });
  }
}

// ---------- Health ----------
app.get('/', (req, res) => res.json({ name: 'Vaultly API', status: 'ok' }));
app.get('/health', (req, res) => res.json({ status: 'ok' }));

// ---------- Auth routes ----------
app.post(
  '/auth/signup',
  authLimiter,
  [
    body('vaultId').isEmail().normalizeEmail(),
    body('password').isLength({ min: 10 }),
    body('securityQuestion').isString().trim().isLength({ min: 5, max: 200 }),
    body('securityAnswer').isString().trim().isLength({ min: 1, max: 200 }),
  ],
  handleValidation,
  async (req, res, next) => {
    try {
      const { vaultId, password, securityQuestion, securityAnswer } = req.body;

      const existing = await db.query('SELECT id FROM users WHERE vault_id = $1', [vaultId]);
      if (existing.rows.length > 0) {
        return res.status(400).json({ error: 'Could not create vault with those details.' });
      }

      const passwordHash = await bcrypt.hash(password, BCRYPT_ROUNDS);
      const answerHash = await bcrypt.hash(securityAnswer.toLowerCase().trim(), BCRYPT_ROUNDS);

      const result = await db.query(
        `INSERT INTO users (vault_id, password_hash, security_question, security_answer_hash, created_at)
         VALUES ($1, $2, $3, $4, NOW()) RETURNING id`,
        [vaultId, passwordHash, securityQuestion, answerHash]
      );

      const token = jwt.sign({ sub: result.rows[0].id }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
      res.status(201).json({ token });
    } catch (err) {
      next(err);
    }
  }
);

app.post(
  '/auth/login',
  authLimiter,
  [body('vaultId').isEmail().normalizeEmail(), body('password').isString()],
  handleValidation,
  async (req, res, next) => {
    try {
      const { vaultId, password } = req.body;
      const result = await db.query('SELECT * FROM users WHERE vault_id = $1', [vaultId]);
      const user = result.rows[0];

      // Always run a hash comparison so response time doesn't reveal which emails exist
      const valid = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH);
      if (!user || !valid) return res.status(401).json({ error: 'Incorrect vault ID or password.' });

      res.json({
        requiresSecurityCheck: true,
        securityQuestion: user.security_question,
        loginToken: jwt.sign({ sub: user.id, stage: 'pending-verification' }, JWT_SECRET, { expiresIn: '10m' }),
      });
    } catch (err) {
      next(err);
    }
  }
);

app.post(
  '/auth/verify-device',
  authLimiter,
  [body('loginToken').isString(), body('answer').isString(), body('deviceId').isString()],
  handleValidation,
  async (req, res, next) => {
    try {
      const { loginToken, answer, deviceId } = req.body;

      let payload;
      try {
        payload = jwt.verify(loginToken, JWT_SECRET);
      } catch {
        return res.status(401).json({ error: 'Login session expired. Please log in again.' });
      }
      if (payload.stage !== 'pending-verification') return res.status(401).json({ error: 'Invalid session.' });

      const result = await db.query('SELECT * FROM users WHERE id = $1', [payload.sub]);
      const user = result.rows[0];
      if (!user) return res.status(401).json({ error: 'Verification failed.' });

      const valid = await bcrypt.compare(answer.toLowerCase().trim(), user.security_answer_hash);
      if (!valid) return res.status(401).json({ error: "That answer doesn't match our records." });

      await db.query(
        `INSERT INTO devices (user_id, device_id, first_seen, last_seen, status)
         VALUES ($1, $2, NOW(), NOW(), 'active')
         ON CONFLICT (device_id) DO UPDATE SET last_seen = NOW(), status = 'active'`,
        [user.id, deviceId]
      );

      const token = jwt.sign({ sub: user.id, deviceId }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
      res.json({ token });
    } catch (err) {
      next(err);
    }
  }
);

// ---------- Device routes (location + remote wipe) ----------
app.use('/device', requireAuth);

app.post(
  '/device/location',
  [
    body('deviceId').isString(),
    body('latitude').isFloat({ min: -90, max: 90 }),
    body('longitude').isFloat({ min: -180, max: 180 }),
    body('accuracyMeters').optional({ nullable: true }).isFloat({ min: 0 }),
    body('batteryPercent').optional({ nullable: true }).isInt({ min: 0, max: 100 }),
  ],
  handleValidation,
  async (req, res, next) => {
    try {
      const { deviceId, latitude, longitude, accuracyMeters, batteryPercent } = req.body;

      const device = await db.query('SELECT id FROM devices WHERE device_id = $1 AND user_id = $2', [deviceId, req.userId]);
      if (device.rows.length === 0) return res.status(403).json({ error: 'Device not recognized.' });

      await db.query(
        `INSERT INTO device_locations (device_id, latitude, longitude, accuracy_meters, battery_percent, recorded_at)
         VALUES ($1, $2, $3, $4, $5, NOW())`,
        [deviceId, latitude, longitude, accuracyMeters || null, batteryPercent || null]
      );
      res.status(204).send();
    } catch (err) {
      next(err);
    }
  }
);

app.get('/device/location/:deviceId', async (req, res, next) => {
  try {
    const { deviceId } = req.params;
    const device = await db.query('SELECT id FROM devices WHERE device_id = $1 AND user_id = $2', [deviceId, req.userId]);
    if (device.rows.length === 0) return res.status(403).json({ error: 'Device not recognized.' });

    const result = await db.query(
      `SELECT latitude, longitude, accuracy_meters, battery_percent, recorded_at
       FROM device_locations WHERE device_id = $1
       ORDER BY recorded_at DESC LIMIT 1`,
      [deviceId]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'No location recorded yet.' });
    res.json(result.rows[0]);
  } catch (err) {
    next(err);
  }
});

app.post('/device/wipe/:deviceId', async (req, res, next) => {
  try {
    const result = await db.query(
      `UPDATE devices SET status = 'wipe_pending' WHERE device_id = $1 AND user_id = $2 RETURNING id`,
      [req.params.deviceId, req.userId]
    );
    if (result.rows.length === 0) return res.status(403).json({ error: 'Device not recognized.' });
    res.json({ status: 'wipe_pending' });
  } catch (err) {
    next(err);
  }
});

app.get('/device/status/:deviceId', async (req, res, next) => {
  try {
    const result = await db.query('SELECT status FROM devices WHERE device_id = $1 AND user_id = $2', [
      req.params.deviceId,
      req.userId,
    ]);
    if (result.rows.length === 0) return res.status(403).json({ error: 'Device not recognized.' });
    res.json({ status: result.rows[0].status });
  } catch (err) {
    next(err);
  }
});

// ---------- Backup routes ----------
// Note: 'messages' is intentionally not included. iOS does not let any
// third-party app read SMS or call history.
app.use('/backup', requireAuth);

app.post(
  '/backup/upload',
  [body('category').isIn(['contacts', 'photos', 'files']), body('payload').isString()],
  handleValidation,
  async (req, res, next) => {
    try {
      const { category, payload } = req.body;
      await db.query(
        `INSERT INTO backups (user_id, category, encrypted_payload, updated_at)
         VALUES ($1, $2, $3, NOW())
         ON CONFLICT (user_id, category) DO UPDATE SET encrypted_payload = $3, updated_at = NOW()`,
        [req.userId, category, encrypt(payload)]
      );
      res.status(204).send();
    } catch (err) {
      next(err);
    }
  }
);

app.get('/backup/restore/:category', async (req, res, next) => {
  try {
    const result = await db.query(
      'SELECT encrypted_payload, updated_at FROM backups WHERE user_id = $1 AND category = $2',
      [req.userId, req.params.category]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'No backup found for this category.' });

    res.json({ data: JSON.parse(decrypt(result.rows[0].encrypted_payload)), updatedAt: result.rows[0].updated_at });
  } catch (err) {
    next(err);
  }
});

// ---------- Error handler (never leaks internals) ----------
app.use((err, req, res, next) => {
  console.error(err.message);
  res.status(err.status || 500).json({ error: 'Something went wrong. Please try again.' });
});

// ---------- Start ----------
if (require.main === module) {
  const PORT = process.env.PORT || 3000;
  initDb()
    .then(() => app.listen(PORT, () => console.log('Vaultly API running on port ' + PORT)))
    .catch((err) => {
      console.error('Database setup failed: ' + err.message);
      process.exit(1);
    });
}

module.exports = { app, initDb };
