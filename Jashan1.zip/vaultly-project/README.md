# Vaultly

Backup, restore-on-a-new-phone, last-known-location and remote wipe.

- `backend/`  - the API server (Node.js). Upload the files inside this folder to GitHub and deploy on Render. See backend/README.md.
- `mobile/`   - the Flutter phone app (Android/iOS). Built on your own computer with the Flutter SDK. Set the server address in mobile/lib/config/api_config.dart.
- `prototype.html` - clickable design prototype; open it in any browser.

The backend and mobile app are separate projects: keep them in separate GitHub repos.
