import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class VerifyScreen extends StatefulWidget {
  final AuthService authService;
  const VerifyScreen({super.key, required this.authService});

  @override
  State<VerifyScreen> createState() => _VerifyScreenState();
}

class _VerifyScreenState extends State<VerifyScreen> {
  final _answerController = TextEditingController();
  bool _loading = false;
  String? _errorMessage;

  Future<void> _submit(String loginToken) async {
    setState(() {
      _loading = true;
      _errorMessage = null;
    });

    try {
      final result = await widget.authService.verifyNewDevice(
        loginToken: loginToken,
        answer: _answerController.text.trim(),
      );

      if (!mounted) return;

      if (result.containsKey('token')) {
        Navigator.pushReplacementNamed(context, '/dashboard');
      } else {
        setState(() => _errorMessage = result['error'] ?? "That answer doesn't match our records.");
      }
    } catch (e) {
      setState(() => _errorMessage = 'Could not reach the server. Check your connection and try again.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _answerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    final loginToken = args['loginToken'] as String;
    final securityQuestion = args['securityQuestion'] as String;

    return Scaffold(
      appBar: AppBar(title: const Text("One more check")),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Since this is a new device, confirm it\'s really you.',
                style: TextStyle(color: Colors.white.withOpacity(0.6)),
              ),
              const SizedBox(height: 20),
              if (_errorMessage != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: Text(_errorMessage!, style: const TextStyle(color: Colors.redAccent)),
                ),
              Text(securityQuestion, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 10),
              TextField(
                controller: _answerController,
                decoration: const InputDecoration(labelText: 'Your answer'),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
                onPressed: _loading ? null : () => _submit(loginToken),
                child: _loading
                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('Verify & restore'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
