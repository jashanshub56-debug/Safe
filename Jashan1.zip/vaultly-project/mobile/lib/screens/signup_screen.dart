import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class SignupScreen extends StatefulWidget {
  final AuthService authService;
  const SignupScreen({super.key, required this.authService});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _vaultIdController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmController = TextEditingController();
  final _questionController = TextEditingController(text: "What was your first pet's name?");
  final _answerController = TextEditingController();

  bool _loading = false;
  String? _errorMessage;

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _errorMessage = null;
    });

    try {
      final result = await widget.authService.signUp(
        vaultId: _vaultIdController.text.trim(),
        password: _passwordController.text,
        securityQuestion: _questionController.text.trim(),
        securityAnswer: _answerController.text.trim(),
      );

      if (!mounted) return;

      if (result.containsKey('token')) {
        Navigator.pushReplacementNamed(context, '/dashboard');
      } else {
        setState(() => _errorMessage = result['error'] ?? 'Could not create your vault. Please try again.');
      }
    } catch (e) {
      setState(() => _errorMessage = 'Could not reach the server. Check your connection and try again.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _vaultIdController.dispose();
    _passwordController.dispose();
    _confirmController.dispose();
    _questionController.dispose();
    _answerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create your vault')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (_errorMessage != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: Text(_errorMessage!, style: const TextStyle(color: Colors.redAccent)),
                  ),
                TextFormField(
                  controller: _vaultIdController,
                  decoration: const InputDecoration(labelText: 'Vault ID (email)'),
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || !value.contains('@')) return 'Enter a valid email address';
                    return null;
                  },
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _passwordController,
                  decoration: const InputDecoration(labelText: 'Password'),
                  obscureText: true,
                  validator: (value) {
                    if (value == null || value.length < 10) return 'At least 10 characters';
                    return null;
                  },
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _confirmController,
                  decoration: const InputDecoration(labelText: 'Confirm password'),
                  obscureText: true,
                  validator: (value) {
                    if (value != _passwordController.text) return "Passwords don't match";
                    return null;
                  },
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _questionController,
                  decoration: const InputDecoration(labelText: 'Security question'),
                  validator: (value) {
                    if (value == null || value.trim().length < 5) return 'Enter a question (5+ characters)';
                    return null;
                  },
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _answerController,
                  decoration: const InputDecoration(labelText: 'Answer'),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) return 'Enter an answer';
                    return null;
                  },
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
                  onPressed: _loading ? null : _submit,
                  child: _loading
                      ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Text('Continue'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
