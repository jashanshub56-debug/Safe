import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../services/location_service.dart';

class DashboardScreen extends StatefulWidget {
  final AuthService authService;
  final LocationService locationService;
  const DashboardScreen({super.key, required this.authService, required this.locationService});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Map<String, dynamic>? _lastLocation;
  bool _loadingLocation = true;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() => _loadingLocation = true);
    // Check in fresh, then fetch whatever the server now has as most recent.
    await widget.locationService.checkInLocation();
    final deviceId = await widget.authService.getDeviceId();
    final location = await widget.locationService.fetchLastKnownLocation(deviceId);
    if (!mounted) return;
    setState(() {
      _lastLocation = location;
      _loadingLocation = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Your vault'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refresh,
            tooltip: 'Refresh location',
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF1F2749),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFF313B6B)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.circle, size: 8, color: Color(0xFF4FD9A8)),
                    const SizedBox(width: 8),
                    const Expanded(
                      child: Text('Protected', style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                    const Icon(Icons.lock, color: Color(0xFF4FD9A8)),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              const Text('Last known location', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 10),
              if (_loadingLocation)
                const Center(child: CircularProgressIndicator())
              else if (_lastLocation != null)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1F2749),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Lat: ${_lastLocation!['latitude']}, Lng: ${_lastLocation!['longitude']}'),
                      const SizedBox(height: 4),
                      Text(
                        'Recorded: ${_lastLocation!['recorded_at']}',
                        style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 12),
                      ),
                    ],
                  ),
                )
              else
                Text(
                  'No location recorded yet — this updates automatically in the background.',
                  style: TextStyle(color: Colors.white.withOpacity(0.5)),
                ),
              const Spacer(),
              OutlinedButton(
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.redAccent,
                  side: const BorderSide(color: Colors.redAccent),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                onPressed: () async {
                  await widget.authService.logOut();
                  if (!mounted) return;
                  Navigator.pushNamedAndRemoveUntil(context, '/', (route) => false);
                },
                child: const Text('Log out'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
