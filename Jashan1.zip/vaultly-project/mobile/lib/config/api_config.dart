// Central place for the backend URL. Change this once you have your real
// Render URL from the deployment steps, e.g. https://vaultly-backend.onrender.com
class ApiConfig {
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://vaultly-backend.onrender.com',
  );
}
