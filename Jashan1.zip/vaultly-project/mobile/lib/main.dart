import 'package:flutter/material.dart';
import 'services/auth_service.dart';
import 'services/location_service.dart';
import 'config/api_config.dart';
import 'screens/welcome_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/login_screen.dart';
import 'screens/verify_screen.dart';
import 'screens/dashboard_screen.dart';

void main() {
  runApp(const VaultlyApp());
}

class VaultlyApp extends StatelessWidget {
  const VaultlyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final authService = AuthService(apiBaseUrl: ApiConfig.baseUrl);
    final locationService = LocationService(
      authService: authService,
      apiBaseUrl: ApiConfig.baseUrl,
    );

    return MaterialApp(
      title: 'Vaultly',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4FD9A8),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF10142A),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const WelcomeScreen(),
        '/signup': (context) => SignupScreen(authService: authService),
        '/login': (context) => LoginScreen(authService: authService),
        '/verify': (context) => VerifyScreen(authService: authService),
        '/dashboard': (context) => DashboardScreen(
              authService: authService,
              locationService: locationService,
            ),
      },
    );
  }
}
