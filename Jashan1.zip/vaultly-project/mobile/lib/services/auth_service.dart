// AuthService
//
// Tokens are stored with flutter_secure_storage, which uses the iOS Keychain
// and Android Keystore under the hood — hardware-backed secure storage, not
// plain SharedPreferences (which any rooted/jailbroken device or malicious
// app with storage access could read in plain text).

import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:device_info_plus/device_info_plus.dart';

class AuthService {
  final _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  final String apiBaseUrl;

  AuthService({this.apiBaseUrl = const String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://api.yourdomain.com',
  )});

  Future<String?> getToken() => _storage.read(key: 'auth_token');

  Future<String> getDeviceId() async {
    final existing = await _storage.read(key: 'device_id');
    if (existing != null) return existing;

    // Generate a stable per-install identifier (not the hardware IMEI/UDID,
    // which both platforms restrict access to for privacy reasons anyway).
    final deviceInfo = DeviceInfoPlugin();
    String seed;
    try {
      final android = await deviceInfo.androidInfo;
      seed = android.id;
    } catch (_) {
      final ios = await deviceInfo.iosInfo;
      seed = ios.identifierForVendor ?? DateTime.now().toIso8601String();
    }
    await _storage.write(key: 'device_id', value: seed);
    return seed;
  }

  Future<Map<String, dynamic>> signUp({
    required String vaultId,
    required String password,
    required String securityQuestion,
    required String securityAnswer,
  }) async {
    final response = await http.post(
      Uri.parse('$apiBaseUrl/auth/signup'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'vaultId': vaultId,
        'password': password,
        'securityQuestion': securityQuestion,
        'securityAnswer': securityAnswer,
      }),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode == 201) {
      await _storage.write(key: 'auth_token', value: data['token']);
    }
    return data;
  }

  /// Step 1 of login — returns whether a security question challenge is needed
  Future<Map<String, dynamic>> login(String vaultId, String password) async {
    final response = await http.post(
      Uri.parse('$apiBaseUrl/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'vaultId': vaultId, 'password': password}),
    );
    return jsonDecode(response.body);
  }

  /// Step 2 — required on any device that hasn't logged in before.
  /// This is exactly what stops someone who steals just the password
  /// (e.g. from a data breach elsewhere) from restoring your data onto
  /// their own phone.
  Future<Map<String, dynamic>> verifyNewDevice({
    required String loginToken,
    required String answer,
  }) async {
    final deviceId = await getDeviceId();
    final response = await http.post(
      Uri.parse('$apiBaseUrl/auth/verify-device'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'loginToken': loginToken,
        'answer': answer,
        'deviceId': deviceId,
      }),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode == 200) {
      await _storage.write(key: 'auth_token', value: data['token']);
    }
    return data;
  }

  Future<void> logOut() async {
    await _storage.delete(key: 'auth_token');
  }
}
