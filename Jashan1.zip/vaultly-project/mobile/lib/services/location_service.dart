// LocationService
//
// HONEST DESIGN NOTE: no app can get a phone's location once it is truly
// powered off — that requires hardware-level support only Apple/Google
// control in their own "Find My" networks. What this service does instead
// is the real, achievable version: it keeps checking in every few minutes
// while the phone is on, caching location locally AND syncing it to the
// server, so whenever the phone goes offline or dies, the last successful
// check-in is still sitting on the server ready to show the user.
//
// It also works without a SIM/cellular signal, because GPS itself doesn't
// need cellular — only satellites or, as a fallback, WiFi-based positioning.
// It syncs to the server over WiFi whenever WiFi is available even with no
// SIM at all.

import 'dart:convert';
import 'package:geolocator/geolocator.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:http/http.dart' as http;
import 'auth_service.dart';

class LocationService {
  final AuthService authService;
  final String apiBaseUrl;
  final Battery _battery = Battery();

  LocationService({required this.authService, required this.apiBaseUrl});

  /// Call this once at app startup, and again from the background task
  /// scheduler (see background_task.dart) every ~15 minutes.
  Future<void> checkInLocation() async {
    final hasPermission = await _ensurePermission();
    if (!hasPermission) return; // never track location without explicit, granted permission

    Position position;
    try {
      position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 20),
      );
    } catch (_) {
      // GPS/WiFi positioning unavailable right now — the last successful
      // check-in already on the server remains the most recent known location.
      return;
    }

    int? batteryLevel;
    try {
      batteryLevel = await _battery.batteryLevel;
    } catch (_) {
      batteryLevel = null;
    }

    await _syncToServer(position, batteryLevel);
  }

  Future<bool> _ensurePermission() async {
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    // "Always" (background) permission is what lets check-ins continue
    // when the app isn't open — request it with a clear in-app explanation
    // first, since both app stores require justifying this to reviewers.
    return permission == LocationPermission.always ||
        permission == LocationPermission.whileInUse;
  }

  Future<void> _syncToServer(Position position, int? batteryLevel) async {
    final token = await authService.getToken();
    final deviceId = await authService.getDeviceId();
    if (token == null || deviceId == null) return;

    try {
      await http
          .post(
            Uri.parse('$apiBaseUrl/device/location'),
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer $token',
            },
            body: jsonEncode({
              'deviceId': deviceId,
              'latitude': position.latitude,
              'longitude': position.longitude,
              'accuracyMeters': position.accuracy,
              'batteryPercent': batteryLevel,
            }),
          )
          .timeout(const Duration(seconds: 15));
      // If this fails (no connectivity at all — no WiFi, no cellular),
      // that's fine: it'll retry on the next scheduled check-in, and the
      // server keeps whatever the last successful sync was.
    } catch (_) {
      // Swallow network errors here deliberately — a failed sync just
      // means "try again next cycle," not a crash.
    }
  }

  /// Fetch the most recent known location from the server (used to power
  /// the "find my old phone" screen after a device is reported lost).
  Future<Map<String, dynamic>?> fetchLastKnownLocation(String deviceId) async {
    final token = await authService.getToken();
    if (token == null) return null;

    final response = await http.get(
      Uri.parse('$apiBaseUrl/device/location/$deviceId'),
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body) as Map<String, dynamic>;
    }
    return null;
  }
}
