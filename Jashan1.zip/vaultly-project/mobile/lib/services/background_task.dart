// Background check-in scheduling.
//
// ANDROID: workmanager can reliably run a task roughly every 15 minutes
// even when the app is closed, which is what keeps "last known location"
// fresh. Some manufacturers (Xiaomi, Huawei, etc.) apply aggressive battery
// optimization that can delay or skip this — the app should show users a
// one-time prompt asking them to disable battery optimization for Vaultly.
//
// iOS: Apple does not allow apps to run arbitrary background tasks on a
// fixed schedule. The closest equivalent is BGAppRefreshTask, which the OS
// grants at its own discretion based on usage patterns — it CANNOT be relied
// on for guaranteed 15-minute check-ins. Practically, iOS check-ins happen
// "whenever iOS feels like it," plus every time the user opens the app.
// This is an Apple platform restriction with no workaround.

import 'package:workmanager/workmanager.dart';
import 'location_service.dart';
import 'auth_service.dart';

const locationCheckInTask = 'vaultly-location-checkin';

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task == locationCheckInTask) {
      final authService = AuthService();
      final locationService = LocationService(
        authService: authService,
        apiBaseUrl: const String.fromEnvironment(
          'API_BASE_URL',
          defaultValue: 'https://api.yourdomain.com',
        ),
      );
      await locationService.checkInLocation();
    }
    return Future.value(true);
  });
}

Future<void> scheduleLocationCheckIns() async {
  await Workmanager().initialize(callbackDispatcher);
  await Workmanager().registerPeriodicTask(
    locationCheckInTask,
    locationCheckInTask,
    frequency: const Duration(minutes: 15), // Android's practical minimum interval
    constraints: Constraints(networkType: NetworkType.notRequired),
  );
}
