// WipeWatcherService
//
// This only works while the app is still installed and able to check in —
// it cannot reach a phone that's had the app deleted, or one that never
// gets network access again. Piggybacks on the same periodic background
// task as the location check-in to avoid draining extra battery.

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'auth_service.dart';

class WipeWatcherService {
  final AuthService authService;
  final String apiBaseUrl;

  WipeWatcherService({required this.authService, required this.apiBaseUrl});

  Future<void> checkAndWipeIfFlagged() async {
    final token = await authService.getToken();
    final deviceId = await authService.getDeviceId();
    if (token == null || deviceId == null) return;

    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/device/status/$deviceId'),
        headers: {'Authorization': 'Bearer $token'},
      );
      if (response.statusCode != 200) return;

      final status = jsonDecode(response.body)['status'];
      if (status == 'wipe_pending') {
        await _wipeLocalData();
      }
    } catch (_) {
      // No connectivity — will check again on the next scheduled run.
    }
  }

  Future<void> _wipeLocalData() async {
    // Clear only what Vaultly itself stores locally: cached backups, the
    // auth token, and any locally cached files this app created. This
    // never touches other apps' data or the rest of the phone — a
    // Vaultly-scoped wipe is all any third-party app is permitted to do
    // on either platform, and it's the honest scope to promise users.
    await authService.logOut();
    // TODO: also clear any locally cached photo/file copies this app keeps,
    // using your chosen local storage/cache directory.
  }
}
